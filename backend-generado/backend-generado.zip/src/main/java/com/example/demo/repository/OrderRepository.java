package com.example.demo.repository;

import com.example.demo.model.Order;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.UUID;
import java.time.LocalDate;
import java.math.BigDecimal;

@Repository
public interface OrderRepository extends JpaRepository<Order, UUID> {
}
